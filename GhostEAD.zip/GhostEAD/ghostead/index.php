<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * GhostEAD - ghost courses report and bulk actions.
 *
 * Written to run on Moodle 3.7+ (PHP 7.1+). Styles live in styles.css and
 * only use the plugin's own classes, so the page looks the same on
 * Bootstrap 4 (3.7-4.1) and Bootstrap 5 (4.2+) themes.
 *
 * @package    tool_ghostead
 * @copyright  2026 Claudivan
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

require_once(__DIR__ . '/../../../config.php');
require_once($CFG->libdir . '/adminlib.php');

use core\output\notification;
use tool_ghostead\local\actions;
use tool_ghostead\local\scanner;

$categoryid = optional_param('category', 0, PARAM_INT);
$bulkaction = optional_param('bulkaction', '', PARAM_ALPHA);
$courseids = optional_param_array('courseids', [], PARAM_INT);

admin_externalpage_setup('tool_ghostead', '', ['category' => $categoryid]);
require_capability('tool/ghostead:manage', context_system::instance());

$result = scanner::scan($categoryid);
$rows = $result['rows'];
$archivecat = (int) get_config('tool_ghostead', 'archivecategory');
$archiveok = $archivecat > 0 && core_course_category::get($archivecat, IGNORE_MISSING);

// Handle bulk actions (POST + sesskey). Only courses currently listed as ghosts are accepted.
if ($bulkaction !== '' && data_submitted() && confirm_sesskey()) {
    $courseids = array_values(array_intersect($courseids, array_keys($rows)));

    if (empty($courseids)) {
        redirect($PAGE->url, get_string('nocourseselected', 'tool_ghostead'), null, notification::NOTIFY_WARNING);
    }

    if ($bulkaction === 'hide') {
        $n = actions::hide($courseids);
        redirect($PAGE->url, get_string('hide_done', 'tool_ghostead', $n), null, notification::NOTIFY_SUCCESS);
    }

    if ($bulkaction === 'archive') {
        if (!$archiveok) {
            redirect($PAGE->url, get_string('noarchivecategory', 'tool_ghostead'), null, notification::NOTIFY_ERROR);
        }
        $n = actions::archive($courseids, $archivecat);
        redirect($PAGE->url, get_string('archive_done', 'tool_ghostead', $n), null, notification::NOTIFY_SUCCESS);
    }
}

$showsize = (bool) get_config('tool_ghostead', 'showsize');
if ($showsize) {
    scanner::add_sizes($rows);
}

$categories = core_course_category::make_categories_list();
$hiddencount = 0;
foreach ($rows as $row) {
    if (!$row->visible) {
        $hiddencount++;
    }
}

echo $OUTPUT->header();
echo $OUTPUT->heading(get_string('pluginname', 'tool_ghostead'));
echo html_writer::start_div('tool-ghostead');

// Stat tiles.
echo html_writer::start_div('gh-stats');
$tiles = [
    ['statanalysed', $result['total']],
    ['statghosts', count($rows)],
    ['stathidden', $hiddencount],
];
foreach ($tiles as $tile) {
    echo html_writer::div(
        html_writer::tag('strong', (int) $tile[1]) . html_writer::span(get_string($tile[0], 'tool_ghostead')),
        'gh-stat'
    );
}
echo html_writer::end_div();

// Category filter.
echo html_writer::start_tag('form', [
    'method' => 'get',
    'action' => $PAGE->url->out_omit_querystring(),
    'class' => 'gh-filter',
]);
echo html_writer::label(get_string('filtercategory', 'tool_ghostead'), 'ghostead-category', true);
echo html_writer::select(
    $categories,
    'category',
    $categoryid,
    [0 => get_string('allcategories', 'tool_ghostead')],
    ['id' => 'ghostead-category', 'class' => 'custom-select form-select']
);
echo html_writer::empty_tag('input', [
    'type' => 'submit',
    'class' => 'btn btn-secondary',
    'value' => get_string('filter', 'tool_ghostead'),
]);
echo html_writer::end_tag('form');

// Empty state.
if (empty($rows)) {
    $settingsurl = new moodle_url('/admin/settings.php', ['section' => 'tool_ghostead_settings']);
    echo html_writer::start_div('gh-card gh-empty');
    echo html_writer::tag('h3', get_string('noghosts', 'tool_ghostead'));
    echo html_writer::tag('p', get_string('emptyhint', 'tool_ghostead'));
    if (has_capability('moodle/site:config', context_system::instance())) {
        echo html_writer::link($settingsurl, get_string('opensettings', 'tool_ghostead'), ['class' => 'gh-btn']);
    }
    echo html_writer::end_div();
    echo html_writer::end_div();
    echo $OUTPUT->footer();
    exit;
}

// Card with the list and the bulk actions.
echo html_writer::start_tag('form', [
    'method' => 'post',
    'action' => $PAGE->url->out_omit_querystring(),
    'class' => 'gh-card',
    'id' => 'ghostead-form',
]);
echo html_writer::input_hidden_params($PAGE->url);
echo html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'sesskey', 'value' => sesskey()]);

echo html_writer::div(
    html_writer::span(get_string('coursestoreview', 'tool_ghostead')) .
    html_writer::tag('small', count($rows) . ' ' . get_string('courses'), ['id' => 'ghostead-count']),
    'gh-bar'
);

foreach ($rows as $row) {
    $cbid = 'ghostead-c' . $row->id;

    // Meta line: shortname, category, last access, people and activities.
    $lastaccess = $row->lastaccess ?
        userdate($row->lastaccess, get_string('strftimedatefullshort', 'langconfig')) :
        get_string('never', 'tool_ghostead');
    $meta = [
        s($row->shortname),
        $categories[$row->category] ?? '-',
        get_string('lastaccess', 'tool_ghostead') . ': ' . $lastaccess,
        $row->students . ' ' . core_text::strtolower(get_string('students', 'tool_ghostead')),
        $row->teachers . ' ' . core_text::strtolower(get_string('teachers', 'tool_ghostead')),
        $row->activities . ' ' . core_text::strtolower(get_string('activities', 'tool_ghostead')),
    ];
    if ($showsize) {
        $meta[] = $row->size === null ? '-' : display_size($row->size);
    }

    // Right side: reason tags, hidden state and score.
    $side = '';
    foreach ($row->reasons as $code) {
        $side .= html_writer::span(get_string('reason_' . $code, 'tool_ghostead'), 'gh-tag');
    }
    if (!$row->visible) {
        $side .= html_writer::span(get_string('hidden', 'tool_ghostead'), 'gh-tag gh-tag-state');
    }
    $level = $row->score >= 85 ? ' gh-high' : ($row->score >= 70 ? ' gh-mid' : '');
    $side .= html_writer::span((int) $row->score, 'gh-score' . $level, [
        'title' => get_string('score', 'tool_ghostead') . ': ' . get_string('score_help', 'tool_ghostead'),
    ]);

    $body = html_writer::link(
        new moodle_url('/course/view.php', ['id' => $row->id]),
        format_string($row->fullname),
        ['target' => '_blank', 'rel' => 'noopener', 'class' => 'gh-name']
    ) . html_writer::span(implode(' · ', $meta), 'gh-meta');

    $checkbox = html_writer::empty_tag('input', [
        'type' => 'checkbox',
        'id' => $cbid,
        'name' => 'courseids[]',
        'value' => $row->id,
        'aria-label' => format_string($row->fullname),
    ]);

    echo html_writer::div(
        $checkbox . html_writer::div($body) . html_writer::div($side, 'gh-side'),
        'gh-row' . ($row->visible ? '' : ' gh-ghosted')
    );
}

// Actions.
echo html_writer::start_div('gh-actions');
echo html_writer::tag('button', get_string('selectall', 'tool_ghostead'), [
    'type' => 'button', 'class' => 'gh-btn', 'id' => 'ghostead-selectall',
]);
echo html_writer::tag('button', get_string('hidebtn', 'tool_ghostead'), [
    'type' => 'submit', 'name' => 'bulkaction', 'value' => 'hide',
    'class' => 'gh-btn gh-primary', 'id' => 'ghostead-hide', 'disabled' => 'disabled',
]);
$archiveattrs = [
    'type' => 'submit', 'name' => 'bulkaction', 'value' => 'archive',
    'class' => 'gh-btn', 'id' => 'ghostead-archive', 'disabled' => 'disabled',
];
if (!$archiveok) {
    $archiveattrs['title'] = get_string('archivenotset', 'tool_ghostead');
    $archiveattrs['data-locked'] = '1';
}
echo html_writer::tag('button', get_string('archivebtn', 'tool_ghostead'), $archiveattrs);
echo html_writer::end_div();

echo html_writer::tag('p', get_string('nothingdeleted', 'tool_ghostead'), ['class' => 'gh-note', 'role' => 'status']);
if (!$archiveok) {
    echo html_writer::tag('p', get_string('archivenotset', 'tool_ghostead'), ['class' => 'gh-note']);
}
echo html_writer::end_tag('form');
echo html_writer::end_div();

// Small progressive enhancement: select all, live counters and a confirmation before archiving.
$strings = [
    'selectall' => get_string('selectall', 'tool_ghostead'),
    'clear' => get_string('clearselection', 'tool_ghostead'),
    'selected' => get_string('selected', 'tool_ghostead'),
    'hide' => get_string('hidebtn', 'tool_ghostead'),
    'archive' => get_string('archivebtn', 'tool_ghostead'),
    'confirm' => get_string('confirmarchive', 'tool_ghostead'),
    'courses' => get_string('courses'),
];
$jsstrings = json_encode($strings, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT);
$js = 'var S = ' . $jsstrings . ";\n" . <<<'JS'
var form = document.getElementById('ghostead-form');
if (form) {
    var boxes = form.querySelectorAll('input[name="courseids[]"]');
    var all = document.getElementById('ghostead-selectall');
    var hide = document.getElementById('ghostead-hide');
    var archive = document.getElementById('ghostead-archive');
    var count = document.getElementById('ghostead-count');
    var total = boxes.length;

    var refresh = function() {
        var n = form.querySelectorAll('input[name="courseids[]"]:checked').length;
        hide.disabled = (n === 0);
        archive.disabled = (n === 0) || archive.hasAttribute('data-locked');
        hide.textContent = S.hide + (n ? ' (' + n + ')' : '');
        archive.textContent = S.archive + (n ? ' (' + n + ')' : '');
        all.textContent = (n === total) ? S.clear : S.selectall;
        count.textContent = n ? (n + ' ' + S.selected + ' / ' + total) : (total + ' ' + S.courses);
    };

    all.addEventListener('click', function() {
        var check = form.querySelectorAll('input[name="courseids[]"]:checked').length !== total;
        Array.prototype.forEach.call(boxes, function(box) { box.checked = check; });
        refresh();
    });
    form.addEventListener('change', refresh);
    form.addEventListener('click', function(e) {
        var row = e.target.closest ? e.target.closest('.gh-row') : null;
        if (row && !e.target.closest('a') && e.target.tagName !== 'INPUT') {
            var box = row.querySelector('input[type="checkbox"]');
            box.checked = !box.checked;
            refresh();
        }
    });
    archive.addEventListener('click', function(e) {
        if (!window.confirm(S.confirm)) {
            e.preventDefault();
        }
    });
    refresh();
}
JS;
$PAGE->requires->js_amd_inline($js);

echo $OUTPUT->footer();
