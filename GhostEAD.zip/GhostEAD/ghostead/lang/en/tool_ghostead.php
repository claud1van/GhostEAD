<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * GhostEAD - English strings.
 *
 * @package    tool_ghostead
 * @copyright  2026 Claudivan
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['action_archive'] = 'Move to archive category';
$string['action_choose'] = 'With selected courses:';
$string['action_hide'] = 'Hide from students';
$string['activities'] = 'Activities';
$string['allcategories'] = 'All categories';
$string['apply'] = 'Apply';
$string['archive_done'] = '{$a} course(s) moved to the archive category.';
$string['archivebtn'] = 'Archive';
$string['archivecategory'] = 'Archive category';
$string['archivecategory_desc'] = 'Category where selected courses are moved by the "Archive" action. Pick a dedicated category such as "Archive". Courses already in it no longer show up in the list.';
$string['archivenotset'] = 'Set the archive category in the settings to enable this action.';
$string['category'] = 'Category';
$string['clearselection'] = 'Clear selection';
$string['confirmarchive'] = 'Move the selected courses to the archive category?';
$string['course'] = 'Course';
$string['coursestoreview'] = 'Courses to review';
$string['emptyhint'] = 'Adjust the inactivity window or the minimum score in the settings to widen the search.';
$string['filter'] = 'Filter';
$string['filtercategory'] = 'Filter by category';
$string['ghostead:manage'] = 'Manage ghost courses (GhostEAD)';
$string['gracedays'] = 'Grace period (days)';
$string['gracedays_desc'] = 'Courses created less than this many days ago are ignored.';
$string['hidden'] = 'Hidden';
$string['hide_done'] = '{$a} course(s) hidden from students.';
$string['hidebtn'] = 'Hide';
$string['inactivewindow'] = 'Inactivity window';
$string['lastaccess'] = 'Last access';
$string['monthsinactive'] = 'Inactivity window (months)';
$string['monthsinactive_desc'] = 'A course with no access for this many months gets the "no recent access" points.';
$string['never'] = 'Never';
$string['noarchivecategory'] = 'No valid archive category configured. Choose one in the GhostEAD settings.';
$string['nocourseselected'] = 'No course selected.';
$string['noghosts'] = 'No ghost courses found with the current settings. 🎉';
$string['notconfigured'] = 'Not configured';
$string['nothingdeleted'] = 'Nothing is deleted: hiding and archiving can be reverted in course management.';
$string['opensettings'] = 'Open settings';
$string['pluginname'] = 'GhostEAD';
$string['privacy:metadata'] = 'GhostEAD only reads existing course data and does not store any personal data.';
$string['reason_empty'] = 'Empty course';
$string['reason_noaccess'] = 'No recent access';
$string['reason_nostudents'] = 'No students';
$string['reason_noteachers'] = 'No teachers';
$string['reasons'] = 'Reasons';
$string['score'] = 'Ghost score';
$string['score_help'] = 'Score from 0 to 100. The higher it is, the more likely the course is abandoned.';
$string['scorethreshold'] = 'Minimum score';
$string['scorethreshold_desc'] = 'Only courses with a score at or above this value (0-100) are listed.';
$string['selectall'] = 'Select all';
$string['selected'] = 'selected';
$string['settingspage'] = 'GhostEAD settings';
$string['showsize'] = 'Show estimated file size';
$string['showsize_desc'] = 'Sums course files for the first 100 listed courses. Can be slow on large sites.';
$string['size'] = 'Files (est.)';
$string['statanalysed'] = 'Courses analysed';
$string['statghosts'] = 'Possible ghosts';
$string['stathidden'] = 'Already hidden in list';
$string['students'] = 'Students';
$string['summary'] = '{$a->count} potential ghost course(s) out of {$a->total} analysed.';
$string['teachers'] = 'Teachers';
$string['visible'] = 'Visible';
