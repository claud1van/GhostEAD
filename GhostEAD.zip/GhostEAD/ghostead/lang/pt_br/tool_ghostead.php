<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * GhostEAD - Portuguese (Brazil) strings.
 *
 * @package    tool_ghostead
 * @copyright  2026 Claudivan
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['action_archive'] = 'Mover para a categoria de arquivo';
$string['action_choose'] = 'Com os cursos selecionados:';
$string['action_hide'] = 'Ocultar dos alunos';
$string['activities'] = 'Atividades';
$string['allcategories'] = 'Todas as categorias';
$string['apply'] = 'Aplicar';
$string['archive_done'] = '{$a} curso(s) movido(s) para a categoria de arquivo.';
$string['archivebtn'] = 'Arquivar';
$string['archivecategory'] = 'Categoria de arquivo';
$string['archivecategory_desc'] = 'Categoria para onde os cursos selecionados são movidos pela ação "Arquivar". Escolha uma categoria dedicada, como "Arquivo". Cursos que já estão nela deixam de aparecer na lista.';
$string['archivenotset'] = 'Defina a categoria de arquivo nas configurações para habilitar esta ação.';
$string['category'] = 'Categoria';
$string['clearselection'] = 'Limpar seleção';
$string['confirmarchive'] = 'Mover os cursos selecionados para a categoria de arquivo?';
$string['course'] = 'Curso';
$string['coursestoreview'] = 'Cursos para revisar';
$string['emptyhint'] = 'Ajuste a janela de inatividade ou a pontuação mínima nas configurações para ampliar a busca.';
$string['filter'] = 'Filtrar';
$string['filtercategory'] = 'Filtrar por categoria';
$string['ghostead:manage'] = 'Gerenciar cursos fantasmas (GhostEAD)';
$string['gracedays'] = 'Período de carência (dias)';
$string['gracedays_desc'] = 'Cursos criados há menos de X dias são ignorados.';
$string['hidden'] = 'Oculto';
$string['hide_done'] = '{$a} curso(s) ocultado(s) dos alunos.';
$string['hidebtn'] = 'Ocultar';
$string['inactivewindow'] = 'Janela de inatividade';
$string['lastaccess'] = 'Último acesso';
$string['monthsinactive'] = 'Janela de inatividade (meses)';
$string['monthsinactive_desc'] = 'Curso sem nenhum acesso por esse número de meses recebe a pontuação de "sem acesso recente".';
$string['never'] = 'Nunca';
$string['noarchivecategory'] = 'Nenhuma categoria de arquivo válida configurada. Escolha uma nas configurações do GhostEAD.';
$string['nocourseselected'] = 'Nenhum curso selecionado.';
$string['noghosts'] = 'Nenhum curso fantasma encontrado com as configurações atuais. 🎉';
$string['notconfigured'] = 'Não configurada';
$string['nothingdeleted'] = 'Nada é apagado: ocultar e arquivar podem ser revertidos no gerenciamento de cursos.';
$string['opensettings'] = 'Abrir configurações';
$string['pluginname'] = 'GhostEAD';
$string['privacy:metadata'] = 'O GhostEAD apenas lê dados de cursos já existentes e não armazena dados pessoais.';
$string['reason_empty'] = 'Curso vazio';
$string['reason_noaccess'] = 'Sem acesso recente';
$string['reason_nostudents'] = 'Sem alunos';
$string['reason_noteachers'] = 'Sem professores';
$string['reasons'] = 'Motivos';
$string['score'] = 'Índice fantasma';
$string['score_help'] = 'Índice de 0 a 100. Quanto maior, mais provável que o curso esteja abandonado.';
$string['scorethreshold'] = 'Pontuação mínima';
$string['scorethreshold_desc'] = 'Só aparecem cursos com pontuação igual ou maior que esse valor (0-100).';
$string['selectall'] = 'Selecionar todos';
$string['selected'] = 'selecionado(s)';
$string['settingspage'] = 'Configurações do GhostEAD';
$string['showsize'] = 'Mostrar tamanho estimado dos arquivos';
$string['showsize_desc'] = 'Soma os arquivos dos 100 primeiros cursos listados. Pode ser lento em sites grandes.';
$string['size'] = 'Arquivos (est.)';
$string['statanalysed'] = 'Cursos analisados';
$string['statghosts'] = 'Possíveis fantasmas';
$string['stathidden'] = 'Já ocultos na lista';
$string['students'] = 'Alunos';
$string['summary'] = '{$a->count} possível(is) curso(s) fantasma(s) em {$a->total} analisado(s).';
$string['teachers'] = 'Professores';
$string['visible'] = 'Visível';
