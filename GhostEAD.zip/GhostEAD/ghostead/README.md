# GhostEAD – Caçador de cursos fantasmas (`tool_ghostead`)

Plugin de administração para Moodle que encontra **cursos fantasmas** (abandonados, vazios ou sem uso) e permite **ocultar** ou **arquivar** em lote, de forma segura e reversível.

> Status: **0.2.0 – alpha**. Teste em ambiente de homologação antes de usar em produção.
>
> Compatibilidade: **Moodle 3.7 ou superior** (PHP 7.1+). O código evita sintaxe de PHP mais novo para rodar em instalações antigas.

## Como funciona

Cada curso recebe um **índice fantasma de 0 a 100**:

| Sinal | Pontos |
|---|---|
| Sem acesso na janela de inatividade (padrão: 6 meses) | 40 |
| Sem alunos | 25 |
| Sem professores | 15 |
| Curso vazio (até 1 atividade, o fórum de avisos automático) | 20 |

Só aparecem na lista cursos com pontuação ≥ mínimo configurado (padrão 60). Cursos criados há menos de 30 dias são ignorados.

## Ações em lote (MVP)

- **Ocultar** dos alunos
- **Arquivar**: move para a categoria de arquivo (você escolhe nas configurações; não há padrão). Cursos que já estão nela deixam de aparecer na lista.

Excluir cursos **não** faz parte do MVP, de propósito.

## Novidades da 0.2.0

- Nova tela: cards de resumo, lista "Cursos para revisar" com motivos e índice coloridos, seleção em lote com contador e confirmação antes de arquivar.
- O menu agora aparece também para quem só tem a permissão `tool/ghostead:manage` (gerentes).
- A categoria de arquivo não tem mais padrão (antes era a categoria 1).
- Cursos já arquivados somem da lista.
- Estilos próprios (`styles.css`), iguais em temas Bootstrap 4 e 5.

## Instalação

1. Copie a pasta `ghostead` para `admin/tool/ghostead` do seu Moodle
   (no Moodle 5.1+, que reorganizou o código em `public/`, o caminho é `public/admin/tool/ghostead`).
2. Acesse *Administração do site > Notificações* e conclua a instalação.
3. Se atualizou de uma versão anterior, limpe os caches (*Administração do site > Desenvolvimento > Limpar todos os caches*) para carregar o novo visual.
4. Configure em *Administração do site > Cursos > Configurações do GhostEAD*.
5. Use em *Administração do site > Cursos > GhostEAD*.

## Limitações conhecidas

- Conta atribuições de papel, não matrículas ativas (matrículas suspensas ainda contam).
- Ignora papéis personalizados sem arquétipo.
- "Último acesso" vem de `user_lastaccess` (inclui professores e admins que entraram no curso).
- O tamanho de arquivos é estimativa (não deduplica conteúdo).

## Roadmap

- [ ] Tarefa agendada + e-mail mensal ao admin com resumo
- [ ] Exportar CSV
- [ ] Eventos de log (auditoria de quem ocultou/arquivou)
- [ ] Marcar curso como "manter" (whitelist)
- [ ] Exclusão com backup automático prévio
- [ ] Contar apenas matrículas ativas
- [ ] Paginação e testes PHPUnit/Behat

## Licença

GNU GPL v3 ou posterior.
