<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * GhostEAD - scans courses and scores how "ghost-like" each one is.
 *
 * @package    tool_ghostead
 * @copyright  2026 Claudivan
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace tool_ghostead\local;

defined('MOODLE_INTERNAL') || die();

/**
 * Computes a 0-100 "ghost score" per course from simple, cheap signals.
 */
class scanner {

    /** @var int Points when nobody accessed the course within the inactivity window. */
    const POINTS_NOACCESS = 40;
    /** @var int Points when the course has no students. */
    const POINTS_NOSTUDENTS = 25;
    /** @var int Points when the course has no teachers. */
    const POINTS_NOTEACHERS = 15;
    /** @var int Points when the course is (almost) empty. */
    const POINTS_EMPTY = 20;

    /**
     * Max activities for a course to count as empty. New courses usually
     * get one automatic "Announcements" forum, so 1 still means empty.
     */
    const EMPTY_MAX_ACTIVITIES = 1;

    /**
     * Scan courses and return the ones at or above the score threshold.
     *
     * @param int $categoryid Restrict to this category (0 = all).
     * @return array ['rows' => stdClass[] sorted by score desc, 'total' => int analysed]
     */
    public static function scan(int $categoryid = 0): array {
        global $DB;

        $months = max(1, (int) (get_config('tool_ghostead', 'monthsinactive') ?: 6));
        $grace = max(0, (int) get_config('tool_ghostead', 'gracedays'));
        $threshold = (int) (get_config('tool_ghostead', 'scorethreshold') ?: 60);

        $now = time();
        $accesscutoff = $now - ($months * 30 * DAYSECS);
        $gracecutoff = $now - ($grace * DAYSECS);

        $params = ['siteid' => SITEID];
        $where = 'c.id <> :siteid';
        if ($categoryid > 0) {
            $where .= ' AND c.category = :cat';
            $params['cat'] = $categoryid;
        }
        // Courses already moved to the archive category are done: do not list them again.
        $archivecat = (int) get_config('tool_ghostead', 'archivecategory');
        if ($archivecat > 0) {
            $where .= ' AND c.category <> :archivecat';
            $params['archivecat'] = $archivecat;
        }
        $courses = $DB->get_records_sql(
            "SELECT c.id, c.fullname, c.shortname, c.category, c.visible, c.timecreated
               FROM {course} c
              WHERE $where
           ORDER BY c.fullname",
            $params
        );

        $lastaccess = $DB->get_records_sql_menu(
            "SELECT courseid, MAX(timeaccess) AS lastaccess
               FROM {user_lastaccess}
           GROUP BY courseid"
        );
        $students = self::count_users_by_archetype(['student']);
        $teachers = self::count_users_by_archetype(['editingteacher', 'teacher']);
        $activities = $DB->get_records_sql_menu(
            "SELECT course, COUNT(1) AS total
               FROM {course_modules}
              WHERE deletioninprogress = 0
           GROUP BY course"
        );

        $rows = [];
        $total = 0;
        foreach ($courses as $course) {
            // Skip brand new courses: they have not had time to be used yet.
            if ($course->timecreated > $gracecutoff) {
                continue;
            }
            $total++;

            $course->lastaccess = (int) ($lastaccess[$course->id] ?? 0);
            $course->students = (int) ($students[$course->id] ?? 0);
            $course->teachers = (int) ($teachers[$course->id] ?? 0);
            $course->activities = (int) ($activities[$course->id] ?? 0);
            $course->size = null;
            $course->score = 0;
            $course->reasons = [];

            if ($course->lastaccess < $accesscutoff) {
                $course->score += self::POINTS_NOACCESS;
                $course->reasons[] = 'noaccess';
            }
            if ($course->students === 0) {
                $course->score += self::POINTS_NOSTUDENTS;
                $course->reasons[] = 'nostudents';
            }
            if ($course->teachers === 0) {
                $course->score += self::POINTS_NOTEACHERS;
                $course->reasons[] = 'noteachers';
            }
            if ($course->activities <= self::EMPTY_MAX_ACTIVITIES) {
                $course->score += self::POINTS_EMPTY;
                $course->reasons[] = 'empty';
            }

            if ($course->score >= $threshold) {
                $rows[$course->id] = $course;
            }
        }

        uasort($rows, function ($a, $b) {
            return [$b->score, $a->lastaccess] <=> [$a->score, $b->lastaccess];
        });

        return ['rows' => $rows, 'total' => $total];
    }

    /**
     * Fill the ->size property (bytes of files in the course context tree).
     *
     * Only the first $limit rows are measured, because summing files is the
     * most expensive query of the plugin. Duplicated file content is counted
     * more than once (this is an estimate, not exact disk usage).
     *
     * @param \stdClass[] $rows Rows returned by scan().
     * @param int $limit Maximum number of rows to measure.
     */
    public static function add_sizes(array $rows, int $limit = 100): void {
        global $DB;

        $done = 0;
        foreach ($rows as $row) {
            if ($done++ >= $limit) {
                break;
            }
            $context = \context_course::instance($row->id, IGNORE_MISSING);
            if (!$context) {
                continue;
            }
            $sql = "SELECT COALESCE(SUM(f.filesize), 0)
                      FROM {files} f
                      JOIN {context} ctx ON ctx.id = f.contextid
                     WHERE f.filename <> '.'
                       AND (ctx.id = :ctxid OR " . $DB->sql_like('ctx.path', ':path') . ")";
            $row->size = (int) $DB->get_field_sql($sql, [
                'ctxid' => $context->id,
                'path' => $DB->sql_like_escape($context->path) . '/%',
            ]);
        }
    }

    /**
     * Count distinct users holding a role of the given archetypes, per course.
     *
     * Limitation (MVP): counts role assignments, not active enrolments, and
     * ignores custom roles that have no archetype.
     *
     * @param string[] $archetypes Role archetypes.
     * @return array courseid => number of users
     */
    private static function count_users_by_archetype(array $archetypes): array {
        global $DB;

        [$insql, $params] = $DB->get_in_or_equal($archetypes, SQL_PARAMS_NAMED, 'arch');
        $params['ctxlevel'] = CONTEXT_COURSE;

        return $DB->get_records_sql_menu(
            "SELECT ctx.instanceid AS courseid, COUNT(DISTINCT ra.userid) AS total
               FROM {role_assignments} ra
               JOIN {role} r ON r.id = ra.roleid
               JOIN {context} ctx ON ctx.id = ra.contextid AND ctx.contextlevel = :ctxlevel
              WHERE r.archetype $insql
           GROUP BY ctx.instanceid",
            $params
        );
    }
}
