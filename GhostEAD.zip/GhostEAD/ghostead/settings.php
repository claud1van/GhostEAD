<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * GhostEAD - admin menu entries and settings.
 *
 * @package    tool_ghostead
 * @copyright  2026 Claudivan
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

// Report page (Site administration > Courses > GhostEAD).
// Registered outside $hassiteconfig so managers (who only hold tool/ghostead:manage) can see it.
$ADMIN->add('courses', new admin_externalpage(
    'tool_ghostead',
    get_string('pluginname', 'tool_ghostead'),
    new moodle_url('/admin/tool/ghostead/index.php'),
    'tool/ghostead:manage'
));

if ($hassiteconfig) {

    // Settings page (Site administration > Courses > GhostEAD settings).
    $settings = new admin_settingpage(
        'tool_ghostead_settings',
        get_string('settingspage', 'tool_ghostead'),
        'moodle/site:config'
    );

    if ($ADMIN->fulltree) {
        $settings->add(new admin_setting_configtext(
            'tool_ghostead/monthsinactive',
            get_string('monthsinactive', 'tool_ghostead'),
            get_string('monthsinactive_desc', 'tool_ghostead'),
            6,
            PARAM_INT
        ));
        $settings->add(new admin_setting_configtext(
            'tool_ghostead/gracedays',
            get_string('gracedays', 'tool_ghostead'),
            get_string('gracedays_desc', 'tool_ghostead'),
            30,
            PARAM_INT
        ));
        $settings->add(new admin_setting_configtext(
            'tool_ghostead/scorethreshold',
            get_string('scorethreshold', 'tool_ghostead'),
            get_string('scorethreshold_desc', 'tool_ghostead'),
            60,
            PARAM_INT
        ));
        // No default on purpose: the admin must pick the archive category consciously.
        $archivechoices = [0 => get_string('notconfigured', 'tool_ghostead')] +
            core_course_category::make_categories_list();
        $settings->add(new admin_setting_configselect(
            'tool_ghostead/archivecategory',
            get_string('archivecategory', 'tool_ghostead'),
            get_string('archivecategory_desc', 'tool_ghostead'),
            0,
            $archivechoices
        ));
        $settings->add(new admin_setting_configcheckbox(
            'tool_ghostead/showsize',
            get_string('showsize', 'tool_ghostead'),
            get_string('showsize_desc', 'tool_ghostead'),
            0
        ));
    }

    $ADMIN->add('courses', $settings);
}
