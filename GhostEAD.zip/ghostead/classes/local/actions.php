<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * GhostEAD - safe, reversible bulk actions.
 *
 * Deleting courses is intentionally NOT part of the MVP.
 *
 * @package    tool_ghostead
 * @copyright  2026 Claudivan
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace tool_ghostead\local;

defined('MOODLE_INTERNAL') || die();

require_once($GLOBALS['CFG']->dirroot . '/course/lib.php');

/**
 * Bulk actions over ghost courses.
 */
class actions {

    /**
     * Hide courses from students.
     *
     * @param int[] $courseids Course ids.
     * @return int Number of courses hidden (already hidden ones are skipped).
     */
    public static function hide(array $courseids): int {
        $count = 0;
        foreach (self::clean_ids($courseids) as $id) {
            $course = get_course($id);
            if (!$course->visible) {
                continue;
            }
            // course_change_visibility() lives in course/lib.php and exists on every release
            // from 3.7 on. It goes through update_course(), so activities follow the course.
            course_change_visibility($course->id, false);
            $count++;
        }
        return $count;
    }

    /**
     * Move courses to the archive category.
     *
     * @param int[] $courseids Course ids.
     * @param int $categoryid Destination category id.
     * @return int Number of courses moved.
     */
    public static function archive(array $courseids, int $categoryid): int {
        $ids = self::clean_ids($courseids);
        if (empty($ids)) {
            return 0;
        }
        move_courses($ids, $categoryid);
        return count($ids);
    }

    /**
     * Remove invalid ids and the site course.
     *
     * @param int[] $courseids Course ids.
     * @return int[]
     */
    private static function clean_ids(array $courseids): array {
        return array_values(array_filter(array_map('intval', $courseids), function ($id) {
            return $id > 0 && $id != SITEID;
        }));
    }
}
